from distutils.core import setup

setup(
    name        = 'nester',
    version     = '1.0.0',
    py_modules  = ['nester'],
    author      = 'Blackpunk',
    author_email= 'blackpunk1337@gmail.com',
    url         = 'https://www.github.com/Blackpunk',
    description = 'A simple printed of nested lists',

)